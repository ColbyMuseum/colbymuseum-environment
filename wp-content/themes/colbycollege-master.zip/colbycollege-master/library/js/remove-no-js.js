window.addEventListener('load', function() {
  const htmlElement = document.documentElement;
  htmlElement.classList.replace('no-js', 'js');
});
