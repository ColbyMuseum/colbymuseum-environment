<?php
/**
 * Template router
 *
 * @package colbymuseum
 */

namespace Colby_Museum;

class Template_Router {
	public function __construct( &$theme ) {
		$this->theme = $theme;
	}
}
